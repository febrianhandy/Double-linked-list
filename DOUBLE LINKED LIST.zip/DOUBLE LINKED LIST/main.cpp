#include "header.h"

int main(){
	int databaru;
	head baru;
	
	int choose;
	do
	{	
		system("cls");
		cout<<"---------------------------\n"
			<<"      OPERASI PADA DOUBLE LINKED LIST\n"
			<<"---------------------------\n"
			<<"[1] Tambah data dari depan \n"
			<<"[2] Tambah data dari belakang\n"
			<<"[3] Hapus data dari depan \n"
			<<"[4] Hapus data dari belakang \n"
			<<"[5] Cetak data \n"
			<<"[6] Clear\n"
			<<"[7] Tampilkan Node Dari Belakang\n"
			<<"[8] Hitung Node\n"
			<<"[0] Exit\n"
			<<"---------------------------\n"
			<<"Masukkan pilihan : "; cin>>choose;
			
			switch(choose)
			{
				case 1:
					cout<<"Penyisipan Simpul Di Depan"<<endl<<endl;
					cout<<"Masukkan angka :"; cin>>databaru;
					insertDepan(baru,databaru);
					cout<<endl;
					system("pause");
					break;
				case 2:
					cout<<"Penyisipan Simpul Di Belakang"<<endl<<endl;
					cout<<"Masukkan angka :"; cin>>databaru;
					insertBelakang(baru,databaru);
					cout<<endl;
					system("pause");
					break;
				case 3:
					hapusDepan(baru);
					system("pause");
					break;
				case 4:
					hapusBelakang(baru);
					system("pause");
					break;
				case 5:
					tampil(baru);
					system("pause");
					break;
				case 6:
					clear (baru);
					system("pause");
					break;
				case 7:
					tampilB(baru);
					system("pause");
					break;
				case 8:
					HITNODE(baru);
					system("pause");
					break;
				case 0:
					cout<<"bye"<<endl;
					break;
				default:
					cout<<"Pilihan tidak tersedia";
					system("pause");
					break;
			}			
	}while (choose !=0);
	return 0;
}
